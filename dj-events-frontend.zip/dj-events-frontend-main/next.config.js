module.exports = {
  images: {
    domains: ['res.cloudinary.com'],
  },
}
